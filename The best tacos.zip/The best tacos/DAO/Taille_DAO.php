<?php

    include_once("tools/DatabaseLinker.php");
    include_once("DTO/Tacos_DTO.php");
    include_once("DTO/Taille_DTO.php");
    include_once("DTO/Viande_DTO.php");
    include_once("DTO/Sauce_DTO.php");

    class Tacos_DAO
    {
        
    }
?>