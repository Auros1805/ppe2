<?php
 
                $listeTacos = $_SESSION['listTacos'][0];
                $listeViande = $_SESSION['listTacos'][1];
                $listeSauce = $_SESSION['listTacos'][2];
                echo sizeof($listeViande[1]);
?>	
	
	<body>
            <div class="bandereau">
                The Best Tacos
            </div>
        <div class="container">
            <table class="tg">
                <thead>
                    <tr>
                        <td>Tacos </td>
                        <td>Taille</td>
                        <td>Viande(s)</td>
                        <td>Sauce</td>
                        <td>Prix</td>
                    </tr>
                <?php

                

                if(!empty($_SESSION['listTacos']))
                {
                    for($i=0; $i < sizeof($listeTacos) ;$i++)
                    {
                        echo '<tr>
                                <td>----</td>
                                <td>'.PanierController::getTaille($listeTacos[$i]->getIdTaille()).'</td>
                                <td>';
                                $viande = $listeViande[$i];
                                for($e = 0;$e < sizeof($listeViande[$i]); $e++)
                                {
                                    echo '<p>'.PanierController::getViande($viande[$e]).'</p>';
                                }
                                echo'</td>
                                <td>';
                                $sauce = $listeSauce[$i];
                                for($e = 0;$e < sizeof($listeSauce[$i]); $e++)
                                {
                                    echo '<p>'.PanierController::getSauce($sauce[$e]).'</p>';
                                }
                                echo'</td>
                                <td>Prix</td>
                                <td><form action="#" method="post"><button name="suppr" value="'.$i.'" class="button">supprimer</button></form></td>    
                            </tr>';
                    }
                }
                ?>
                    <tr>
                        <td><a href="?page=CommandeTacos" class="button">nouveau Tacos</a></td>
                        <td>-----</td>
                        <td>-----</td>
                        <td>-----</td>
                        <td>-----</td>
                    </tr>
                </thead>
            </table>
        <?php
            if(isset($_POST['suppr']))
            {
                unset($_SESSION['listTacos'][0][$_POST['suppr']]);
                $_SESSION['listTacos'][0] = array_merge($_SESSION['listTacos'][0]);
                
                unset($_SESSION['listTacos'][1][$_POST['suppr']]);
                $_SESSION['listTacos'][1] = array_merge($_SESSION['listTacos'][1]);
                
                unset($_SESSION['listTacos'][2][$_POST['suppr']]);
                $_SESSION['listTacos'][2] = array_merge($_SESSION['listTacos'][2]);
            }
        ?>
        </div>
        
        </body>
