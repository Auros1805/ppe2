
    <body>
            <div class="bandereau">
                The Best Tacos
            </div>
            <div class="container">
                <img class="img" src="https://media.discordapp.net/attachments/649965278717018136/698096777345236992/tacos1.jpg">
                    <div class="btn">
                        <a href="?page=CommandeTacos" class="button">Cliquez ici</a>
                    </div>
                </form>
            </div>
        
        </body>
