<?php
    
?>	
	
	<body>
            <div class="bandereau">
                The Best Tacos
            </div>
            <div class="container">
                <p>adresse :</p><input type="text" id="name" name="name" required minlength="4" maxlength="8" size="10">
                <p>Nom :</p><input type="text" id="name" name="name" required minlength="4" maxlength="8" size="10">
                <p>Prénom :</p><input type="text" id="name" name="name" required minlength="4" maxlength="8" size="10">
            </div>
            
        </body>
